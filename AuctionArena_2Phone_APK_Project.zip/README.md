# Auction Arena — 2 Phone APK

A two-player automatic auction game. The first phone creates the game room, but there is no human host: the game logic controls the auction.

Categories: Marvel, DC, Cricket, Football
Budgets: preset or custom
Slots: 4 or 5
Photos: loaded from Wikipedia's public article thumbnails at runtime
Networking: PeerJS cloud signaling + direct peer connection

## Build without Linux / Android Studio

1. Create a GitHub repository.
2. Upload this entire project.
3. Commit to the `main` branch.
4. Open the repository's Actions tab.
5. Run "Build APK" if it did not start automatically.
6. Open the completed workflow run and download the `AuctionArena-debug` artifact.
7. Extract the artifact and install `app-debug.apk` on both phones.

Both phones need internet access during play because room connection and photos use online services.
